//
//  ViewController.swift
//  Command
//
//  Created by Pavlo Ratushnyi on 1/10/20.
//  Copyright © 2020 Pavlo Ratushnyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        eveningProgramm.commands.append(lightOnCommand)
        eveningProgramm.commands.append(heatCommand)
        eveningProgramm.start()
    }

    @IBAction func stopButtonTap(_ sender: Any) {
        eveningProgramm.stop()
    }
    
}

final class LightOutside {
    var intensity: Double = 1.0
    
    func switchOn() {
        print("Ligth's switched on")
    }
    func switchOff() {
        print("Light's switched off")
    }
}

final class HeatingCooling {
    var temperature: Double = 21.5
    var mode: String {
        return temperature >= 25 ? "cooling" : "heating"
    }
    
    func start() {
        print("Start \(mode)")
    }
    
    func stop() {
        print("Stop \(mode)")
    }
}

protocol Command {
    func execute()
    func cancel()
}

final class SwitchOnLightCommand: Command {
    
    var light: LightOutside
    
    init(light: LightOutside) {
        self.light = light
    }
    
    func execute() {
        light.switchOn()
    }
    func cancel() {
        light.switchOff()
    }
}

final class StartHeatingCommand: Command {
    
    var heaterCooler: HeatingCooling
    
    init(heater: HeatingCooling) {
        self.heaterCooler = heater
    }
    
    func execute() {
       
        heaterCooler.start()
    }
    
    func cancel() {
        heaterCooler.stop()
    }
}

final class Programm {
    var commands: [Command] = []
    
    func start() {
        commands.forEach { $0.execute() }
    }
    func stop() {
        commands.forEach { $0.cancel() }
    }
    
}

let light = LightOutside()
let heater = HeatingCooling()

let lightOnCommand = SwitchOnLightCommand(light: light)
let heatCommand = StartHeatingCommand(heater: heater)

let eveningProgramm = Programm()

