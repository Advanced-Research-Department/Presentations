//
//  ViewController.swift
//  HamburgerBuilder
//
//  Created by Pavlo Ratushnyi on 1/2/20.
//  Copyright © 2020 Pavlo Ratushnyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let builder = HamburgerBuilder()
    var burger: Hamburger?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func makeCombo1(_ sender: Any) {
        let burgerFlipper = Employee()
        if let combo1 = try? burgerFlipper.createCombo1() {
          print("Nom nom " + combo1.description)
        }
    }
    
    @IBAction func makeSpecial(_ sender: Any) {
        let burgerFlipper = Employee()
        if let kittenBurger = try?
          burgerFlipper.createKittenSpecial() {
          print("Nom nom nom " + kittenBurger.description)
        } else {
          print("Sorry, no kitten burgers here... :[")
        }
    }
    
    @IBAction func buildHamburger(_ sender: Any) {
        burger = builder.build()
        print(burger!.description)
    }
    
    @IBAction func addTomatoes(_ sender: UIButton) {
        if !sender.isSelected {
            builder.addToppings(.tomatoes)
            sender.isSelected = true
        } else {
            builder.removeToppings(.tomatoes)
            sender.isSelected = false
        }
    }
    
    
    @IBAction func addPickles(_ sender: UIButton) {
        if !sender.isSelected {
            builder.addToppings(.pickles)
            sender.isSelected = true
        } else {
            builder.removeToppings(.pickles)
            sender.isSelected = false
        }
    }
    
    
    @IBAction func addLettuce(_ sender: UIButton) {
        if !sender.isSelected {
            builder.addToppings(.lettuce)
            sender.isSelected = true
        } else {
            builder.removeToppings(.lettuce)
            sender.isSelected = false
        }
    }
    
    @IBAction func addChease(_ sender: UIButton) {
        if !sender.isSelected {
            builder.addToppings(.cheese)
            sender.isSelected = true
        } else {
            builder.removeToppings(.cheese)
            sender.isSelected = false
        }
    }
    
    @IBAction func addSecret(_ sender: UIButton) {
        if !sender.isSelected {
            builder.addSauces(.secret)
            sender.isSelected = true
        } else {
            builder.removeSauces(.secret)
            sender.isSelected = false
        }
    }
    
    @IBAction func addKetchup(_ sender: UIButton) {
         if !sender.isSelected {
                   builder.addSauces(.ketchup)
                   sender.isSelected = true
               } else {
                   builder.removeSauces(.ketchup)
                   sender.isSelected = false
               }
    }
    
    @IBAction func addMustard(_ sender: UIButton) {
         if !sender.isSelected {
                   builder.addSauces(.mustard)
                   sender.isSelected = true
               } else {
                   builder.removeSauces(.mustard)
                   sender.isSelected = false
               }
    }
    
    
    @IBAction func addMayonnaise(_ sender: UIButton) {
         if !sender.isSelected {
                   builder.addSauces(.mayonnaise)
                   sender.isSelected = true
               } else {
                   builder.removeSauces(.mayonnaise)
                   sender.isSelected = false
               }
    }
    
    
    
}

