//
//  HamburgerBuider.swift
//  HamburgerBuilder
//
//  Created by Pavlo Ratushnyi on 1/2/20.
//  Copyright © 2020 Pavlo Ratushnyi. All rights reserved.
//

import Foundation

public class HamburgerBuilder {
    
    public enum Error: Swift.Error {
      case soldOut
    }
    
    public private(set) var meat: Meat = .beef
    public private(set) var sauces: Sauces = []
    public private(set) var toppings: Toppings = []
    
    private var soldOutMeats: [Meat] = [.kitten]
    
    public func build() -> Hamburger {
        return Hamburger(meat: meat, sauce: sauces, toppings: toppings)
    }
        
    // Hamburger components
    public func addSauces(_ sauce: Sauces) {
        sauces.insert(sauce)
    }
    public func removeSauces(_ sauce: Sauces) {
        sauces.remove(sauce)
    }
    public func addToppings(_ topping: Toppings) {
        toppings.insert(topping)
    }
    public func removeToppings(_ topping: Toppings) {
        toppings.remove(topping)
    }
    
    // Hamburger meat
    public func setMeat(_ meat: Meat) throws {
      guard isAvailable(meat) else { throw Error.soldOut }
      self.meat = meat
    }
    public func isAvailable(_ meat: Meat) -> Bool {
      return !soldOutMeats.contains(meat)
    }
    
    
   
    
}
