//
//  PanframeRoof.swift
//  Decorator
//
//  Created by Pavlo Ratushnyi on 3/18/19.
//  Copyright © 2019 Pavlo Ratushnyi. All rights reserved.
//

import Foundation

class PanframeRoof: MercedesDecorator {
    
    required init (decorated: MercedesProtocol) {
        super.init(decorated: decorated)
    }
    
    override func getTitle() -> String {
        return super.getTitle() + " premium roof"
    }
    
    override func getPrice() -> Double {
        return super.getPrice() + 2000
    }
}


class AlloyWheels: MercedesDecorator {
    
    required init (decorated: MercedesProtocol) {
        super.init(decorated: decorated)
    }
    
    override func getTitle() -> String {
        return super.getTitle() + " alloy wheels"
    }
    
    override func getPrice() -> Double {
        return super.getPrice() + 1500
    }
}
