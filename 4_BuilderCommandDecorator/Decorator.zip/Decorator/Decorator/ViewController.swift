//
//  ViewController.swift
//  Decorator
//
//  Created by Pavlo Ratushnyi on 3/18/19.
//  Copyright © 2019 Pavlo Ratushnyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var mercedes: MercedesProtocol = MercedesCLA()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var typeCar: UILabel!
    
    
    @IBAction func segmentControlChanged(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex {
        case 0:
            mercedes = MercedesCLA()
            priceLabel.text = String(mercedes.getPrice())
            typeCar.text = mercedes.getTitle()
        case 1:
            mercedes = MercedesCLA()
            mercedes = AlloyWheels(decorated: mercedes)
            priceLabel.text = String(mercedes.getPrice())
            typeCar.text = mercedes.getTitle()
        case 2:
            mercedes = MercedesCLA()
            mercedes = PanframeRoof(decorated: mercedes)
            priceLabel.text = String(mercedes.getPrice())
            typeCar.text = mercedes.getTitle()
        default:
            break
        }
    }
    
    
    
}

