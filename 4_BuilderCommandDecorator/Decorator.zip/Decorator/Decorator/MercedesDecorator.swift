//
//  MercedesDecorator.swift
//  Decorator
//
//  Created by Pavlo Ratushnyi on 3/18/19.
//  Copyright © 2019 Pavlo Ratushnyi. All rights reserved.
//

import Foundation

class MercedesDecorator: MercedesProtocol {
    
    private let decoratedType: MercedesProtocol
    
    required init (decorated: MercedesProtocol) {
        self.decoratedType = decorated
    }
    
    
    func getTitle() -> String {
        return decoratedType.getTitle()
    }
    
    func getPrice() -> Double {
        return decoratedType.getPrice()
    }
    
   
}
