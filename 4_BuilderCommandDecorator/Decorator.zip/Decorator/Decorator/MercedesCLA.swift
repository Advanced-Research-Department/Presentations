//
//  MercedesCLA.swift
//  Decorator
//
//  Created by Pavlo Ratushnyi on 3/18/19.
//  Copyright © 2019 Pavlo Ratushnyi. All rights reserved.
//

import Foundation

class MercedesCLA: MercedesProtocol {
    func getTitle() -> String {
        return "MercedesCLA"
    }
    
    func getPrice() -> Double {
        return 12000
    }
    
    
}
